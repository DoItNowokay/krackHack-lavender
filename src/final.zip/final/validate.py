''' 
this script is for checking if the transection is valid or not
'''

# import pandas as pd
import rsa_algo
# import json
# # data of donor
# donor="{'name':'bilal','blood_group':'x+','organ':'kidney1','age':10}"
# # doctor="{'name':'chetan','donor_name':'bilal','donor_age':10,'donor_organ':'kidney1','recipient_name':'bilal','recipient_age':10,'recipient_organ':'kidney2'}"
# recipient="{'name':'bilal','blood_group':'x+','organ':'kidney2','age':10}"

# # key for all
# donor_public,donor_private=rsa_algo.generate_key_pair()
# # doctor_public,doctor_private=rsa_algo.generate_key_pair()
# recipient_public,recipient_private=rsa_algo.generate_key_pair()

# # encrption using private key
# enc_donor=rsa_algo.encrypt_message(donor_private,donor)
# # enc_doctor=rsa_algo.encrypt_message(doctor_private,doctor)
# enc_reci=rsa_algo.encrypt_message(recipient_private,recipient)

def decrypt(enc_data,public_key):
    return eval(rsa_algo.decrypt_message(public_key,enc_data))
# checking if everythign is fine 
def check_validity(donor,recipient):
    try:
        # doctor[0]=decrypt(doctor[0],doctor[1])
    # print(donor[0],donor[1])
        donor[0]=decrypt(donor[0],donor[1])
        recipient[0]=decrypt(recipient[0],recipient[1])
    except:
    #     print()
        return False
    if(donor[0]['Organ']==recipient[0]['organ']):
        return True
    # print(1111)
    return False


# decryption in dictionary
# dec_donor=decrypt(enc_donor,donor_public)
# dec_doctor=decrypt(enc_doctor,doctor_public)
# dec_recipient=decrypt(enc_reci,recipient_public)

# def check_validity():
#     return check_valid([enc_donor,donor_public],[enc_doctor,doctor_public],[enc_reci,recipient_public])

# print(check_validity([enc_donor,donor_public],[enc_doctor,doctor_public],[enc_reci,recipient_public]))